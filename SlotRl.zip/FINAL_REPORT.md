# SlotRL Final Research Report

## Executive summary

SlotRL studies revenue-aware outpatient appointment overbooking using a
time-aware no-show model, a constrained Gymnasium scheduling environment, and
MaskablePPO. The project compares learned policies with operational heuristics
under an explicitly documented offline simulator.

The main result is that the tuned expected-load heuristic achieved the highest
mean net reward: **$2,331.73 per provider-day**. The best primary PPO seed
achieved **$2,310.57 per day**, approximately 0.9% lower. PPO reduced overtime
relative to always-overbooking, but did not outperform the simpler heuristic.

This negative result is retained. Under the current state, reward, demand
process, and cost assumptions, reinforcement learning did not provide enough
benefit to justify its additional complexity.

## Experimental design

The raw appointment data were cleaned using explicit date and age checks. The
no-show model used chronological training, calibration, and held-out test
slices. XGBoost was compared with logistic regression, and raw and calibrated
probabilities were evaluated separately.

The environment represents one provider-day with 16 appointment slots, a slot
capacity of two, 20 incoming requests, and a daily double-booking cap. The
reward is:

```text
visit value × patients seen
- overtime cost × slots with two shows
- decline cost × declined requests
```

The primary PPO used action masking. The research ablation suite contained 15
models: five raw-probability masked PPO seeds, five calibrated-probability
unmasked PPO seeds with an explicit invalid-action penalty, and five calibrated
masked PPO seeds with `gamma=1.0`.

Every model was evaluated on the same chronological evaluation pool and the
same paired simulated days. Each policy received 4,000 evaluation days.

## Primary policy results

| Policy | Mean net reward/day | 95% bootstrap interval | Mean overtime/day | Mean double bookings/day |
|---|---:|---:|---:|---:|
| Expected-load | $2,331.73 | $2,325.00–$2,338.94 | 2.11 | 4.07 |
| PPO seed 44 | $2,310.57 | $2,303.64–$2,317.79 | 2.47 | 4.00 |
| PPO seed 22 | $2,308.83 | $2,301.86–$2,316.22 | 2.50 | 4.00 |
| PPO seed 11 | $2,305.25 | $2,298.27–$2,312.23 | 2.56 | 4.00 |
| PPO seed 55 | $2,301.27 | $2,294.23–$2,308.49 | 2.62 | 4.00 |
| PPO seed 33 | $2,297.52 | $2,290.54–$2,304.80 | 2.69 | 4.03 |
| Threshold | $2,297.01 | $2,289.92–$2,304.36 | 2.69 | 4.00 |
| Always-overbook | $2,136.71 | $2,130.59–$2,142.83 | 5.37 | 8.00 |
| Single-book | $1,885.75 | $1,878.66–$1,892.95 | 0.00 | 0.00 |

All primary PPO seeds were significantly below expected-load in paired Wilcoxon
comparisons. The best primary PPO seed was approximately $174/day better than
always-overbook and approximately $425/day better than single-book.

## Ablation results

| Variant | Mean across five seeds | Best seed |
|---|---:|---:|
| Calibrated masked PPO, gamma=1.0 | $2,307.38 | $2,321.51 |
| Raw masked PPO | $2,305.73 | $2,313.80 |
| Calibrated unmasked PPO | $2,303.60 | $2,311.73 |

The unmasked models generated very few invalid actions. This shows that the
agent learned the action structure under the explicit penalty, not that action
masking is universally unnecessary.

## Calibration findings

The held-out XGBoost model achieved ROC-AUC 0.7337 and PR-AUC 0.3433. Raw
probabilities had Brier score 0.13631 and ECE 0.03155. Sigmoid calibration
preserved ranking metrics but produced Brier score 0.13663 and ECE 0.03405.

Calibration therefore did not improve formal probability-quality metrics on
this split. In the downstream policy simulation, calibrated probabilities
improved expected-load reward by approximately $7.50/day. Calibration quality
and decision quality should therefore be reported separately.

## Fairness, robustness, and limitations

The fairness audit measured double-booking exposure by age band and scholarship
indicator. PPO exposure was more balanced than always-overbooking in the tested
simulation. This is an exposure audit only. It does not measure equal service
outcomes, access, wait times, clinical priority, or disparate impact.

The sensitivity analysis varied overtime cost from 30 to 150 and base no-show
rate from 0.10 to 0.30. Expected-load remained the strongest tested baseline
across the grid.

The project is an offline simulation, not a deployment or causal experiment.
The request process, capacity, visit value, overtime cost, and decline cost are
assumptions. The simulator does not model cancellations, rebooking, wait
times, appointment priority, provider heterogeneity, or staffing constraints.
The historical no-show label may also reflect the original clinic's policies.

## Final conclusion

The project is complete as an offline research prototype. The evidence supports
using expected-load as the best policy under the current simulator. PPO adds a
reproducible learning-based comparison and performs competitively, but these
results do not justify claiming that reinforcement learning is superior.

The appropriate production next step is validation with real scheduling logs,
reviewed cost assumptions, shadow-mode testing, operational guardrails, and a
pre-registered policy evaluation plan.
